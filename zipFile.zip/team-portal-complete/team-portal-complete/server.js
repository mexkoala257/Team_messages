const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const multer = require('multer');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.static('public'));

// Initialize SQLite Database
const db = new sqlite3.Database('./team-portal.db', (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

// Create tables if they don't exist
function initializeDatabase() {
    db.serialize(() => {
        // Messages table
        db.run(`CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            text TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Updates table
        db.run(`CREATE TABLE IF NOT EXISTS updates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            status TEXT NOT NULL,
            text TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // Photos table
        db.run(`CREATE TABLE IF NOT EXISTS photos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            data TEXT NOT NULL,
            caption TEXT,
            timestamp TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        // PDFs table
        db.run(`CREATE TABLE IF NOT EXISTS pdfs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            data TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`);

        console.log('Database tables initialized');
    });
}

// ========== MESSAGES ENDPOINTS ==========

// Get all messages
app.get('/api/messages', (req, res) => {
    db.all('SELECT * FROM messages ORDER BY id DESC', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Add a message
app.post('/api/messages', (req, res) => {
    const { name, text, timestamp } = req.body;
    
    if (!name || !text) {
        res.status(400).json({ error: 'Name and text are required' });
        return;
    }

    db.run(
        'INSERT INTO messages (name, text, timestamp) VALUES (?, ?, ?)',
        [name, text, timestamp || new Date().toISOString()],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ id: this.lastID, name, text, timestamp });
        }
    );
});

// Delete a message
app.delete('/api/messages/:id', (req, res) => {
    db.run('DELETE FROM messages WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ deleted: this.changes });
    });
});

// ========== UPDATES ENDPOINTS ==========

// Get all updates
app.get('/api/updates', (req, res) => {
    db.all('SELECT * FROM updates ORDER BY id DESC', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Add an update
app.post('/api/updates', (req, res) => {
    const { name, status, text, timestamp } = req.body;
    
    if (!name || !status || !text) {
        res.status(400).json({ error: 'Name, status, and text are required' });
        return;
    }

    db.run(
        'INSERT INTO updates (name, status, text, timestamp) VALUES (?, ?, ?, ?)',
        [name, status, text, timestamp || new Date().toISOString()],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ id: this.lastID, name, status, text, timestamp });
        }
    );
});

// Delete an update
app.delete('/api/updates/:id', (req, res) => {
    db.run('DELETE FROM updates WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ deleted: this.changes });
    });
});

// ========== PHOTOS ENDPOINTS ==========

// Get all photos
app.get('/api/photos', (req, res) => {
    db.all('SELECT * FROM photos ORDER BY id DESC', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Add a photo
app.post('/api/photos', (req, res) => {
    const { data, caption, timestamp } = req.body;
    
    if (!data) {
        res.status(400).json({ error: 'Photo data is required' });
        return;
    }

    db.run(
        'INSERT INTO photos (data, caption, timestamp) VALUES (?, ?, ?)',
        [data, caption || '', timestamp || new Date().toISOString()],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ id: this.lastID, data, caption, timestamp });
        }
    );
});

// Delete a photo
app.delete('/api/photos/:id', (req, res) => {
    db.run('DELETE FROM photos WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ deleted: this.changes });
    });
});

// ========== PDFS ENDPOINTS ==========

// Get all PDFs
app.get('/api/pdfs', (req, res) => {
    db.all('SELECT * FROM pdfs ORDER BY id DESC', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});

// Add a PDF
app.post('/api/pdfs', (req, res) => {
    const { name, data, timestamp } = req.body;
    
    if (!name || !data) {
        res.status(400).json({ error: 'Name and data are required' });
        return;
    }

    db.run(
        'INSERT INTO pdfs (name, data, timestamp) VALUES (?, ?, ?)',
        [name, data, timestamp || new Date().toISOString()],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({ id: this.lastID, name, data, timestamp });
        }
    );
});

// Delete a PDF
app.delete('/api/pdfs/:id', (req, res) => {
    db.run('DELETE FROM pdfs WHERE id = ?', [req.params.id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json({ deleted: this.changes });
    });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Start server
app.listen(PORT, () => {
    console.log(`Team Portal server running on port ${PORT}`);
    console.log(`Access the portal at: http://localhost:${PORT}`);
});

// Graceful shutdown
process.on('SIGINT', () => {
    db.close((err) => {
        if (err) {
            console.error('Error closing database:', err);
        } else {
            console.log('Database connection closed');
        }
        process.exit(0);
    });
});
